/******************************************************************************
 |                                                                            |
 |  Copyright 2023, All rights reserved, Sylvain Saucier                      |
 |  sylvain@sysau.com                                                         |
 |  Distributed under Affero GNU Public Licence version 3                     |
 |  Commercial licence available upon request                                 |
 |                                                                            |
 ******************************************************************************/
 
#ifndef ___ftime_h
#define ___ftime_h
double ftime(void);
#endif

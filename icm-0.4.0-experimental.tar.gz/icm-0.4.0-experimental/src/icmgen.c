/*  Copyright 2023, All rights reserved, Sylvain Saucier
    sylvain@sysau.com
    Distributed under Affero GNU Public Licence version 3
    Commercial licence available upon request */

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "libicm.h"

#define ___icm_BLOCKSIZE (4096) // size of uint64_t array, size in mb is 8 times greater
#define ___icm_BLOCK_BYTES (___icm_BLOCKSIZE * sizeof(uint64_t))

void flush_buffer_hex(uint64_t* buffer, uint64_t bytes)
{
    int x = 0;
    int whole_int = bytes / 8;
    int partial_int = bytes % 8;

    while( x < whole_int )
        printf("%016llx", buffer[x++]);

    switch (partial_int)
    {
        case 1:
            printf("%02llx", 0xff & buffer[x++]);
            break;

        case 2:
            printf("%04llx", 0xffff & buffer[x++]);
            break;

        case 3:
            printf("%06llx", 0xffffff & buffer[x++]);
            break;

        case 4:
            printf("%08llx", 0xffffffff & buffer[x++]);
            break;

        case 5:
            printf("%010llx", 0xffffffffff & buffer[x++]);
            break;

        case 6:
            printf("%012llx", 0xffffffffffff & buffer[x++]);
            break;

        case 7:
            printf("%014llx", 0xffffffffffffff & buffer[x++]);
            break;
    }
}

void flush_buffer_bin(uint64_t* buffer, uint64_t bytes)
{
    fwrite(buffer, sizeof(uint8_t), bytes, stdout);
}

void fillbuffer(icm_state_t* state, uint64_t* buffer, uint64_t buffer_size, uint64_t first)
{
    if(!first)
    {
        icm_get(state, buffer, buffer_size, 0);
    }
    else
    { 
        uint64_t y = 0;
        while( y < buffer_size )
        {
            for( int x = 0; x < NUM_THREADS; x++ )
            {
                state->nodes[x] = 0;
            }
            icm_get(state, buffer + y, 1, 0);
            y++;
        }
    }
}

int main(int argc, const char * argv[])
{
    uint64_t current_arg = argc - 1;
    uint32_t cfg_hex = 0;
    uint32_t cfg_info = 0;
    uint32_t cfg_first = 0;
    uint32_t cfg_void = 0;
    uint64_t* buffer;
    
    buffer = (uint64_t*) calloc(___icm_BLOCKSIZE, sizeof(uint64_t));

    if( buffer == NULL )
    {
        fprintf(stderr, "icm - ERROR - cannot allocate memory buffer");
        return 1;
    }

    for( int x = 1; x < argc; x++ )
    {
        if(!strcmp("void", argv[x]) || !strcmp("v", argv[x])){
            cfg_void = 1;
        }
        else if(!strcmp("info", argv[x]) || !strcmp("i", argv[x])){
            cfg_info = 1;
        }
        else if(!strcmp("first", argv[x]) || !strcmp("f", argv[x])){
            cfg_first = 1;
        }
        else if(!strcmp("hex", argv[x]) || !strcmp("h", argv[x])){
            cfg_hex = 1;
        }
    }

    icm_state_t state;
    icm_init(&state);
    icm_go(&state);

#ifdef ICM_EXPERIMENTAL
    fprintf(stderr, "EXPERIMENTAL FEATURES ENABLED\n");
    fprintf(stderr, "EXPERIMENTAL FEATURES ENABLED\n");
    fprintf(stderr, "EXPERIMENTAL FEATURES ENABLED\n");
    icm_join(&state);
#else
    while( 1 )
    {
        fillbuffer(&state, buffer, ___icm_BLOCKSIZE, cfg_first);
        if(cfg_void == 0)
        {
            if( cfg_hex )
                flush_buffer_hex( buffer, ___icm_BLOCK_BYTES );
            else
                flush_buffer_bin( buffer, ___icm_BLOCK_BYTES );
        }

        if( cfg_info )
        {
            fprintf(stderr, "\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b");
            fprintf(stderr, "\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b");
            fprintf(stderr, "\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b\b");
            for( int x = 0; x < NUM_THREADS; x++)
            {
                fprintf(stderr, "%016llx", state.nodes[x]);
            }
        }
    }
#endif

    icm_stop(&state);
    free(buffer);

    return 0;
}
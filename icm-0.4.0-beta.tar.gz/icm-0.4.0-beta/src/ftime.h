/**
* @file ftime.h
* @author Sylvain Saucier <sylvain@sysau.com>
* @version 0.4.0
* @section LICENSE *
* This program is free software; you can redistribute it and/or
* modify it under the terms of the Affero GNU Public Licence version 3.
* Other licences available upon request.
* @section DESCRIPTION *
* Function definition for the ftime library */
#ifndef ___ftime_h
#define ___ftime_h
double ftime(void);
#endif

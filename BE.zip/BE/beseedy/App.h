/*
 * Copyright 2024, My Name <my@email.address>
 * All rights reserved. Distributed under the terms of the MIT license.
 */
#ifndef APP_H
#define APP_H


#include <Application.h>
#include <cstdio>
#include "../../src/libseedy/libseedy64.h"

class App : public BApplication
{
public:
							App();
	virtual					~App();

private:
};

#endif // APP_H
